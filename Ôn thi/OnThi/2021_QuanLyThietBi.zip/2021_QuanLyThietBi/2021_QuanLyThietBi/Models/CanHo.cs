﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2021_QuanLyThietBi.Models
{
    public class CanHo
    {
        public string MaCanHo { get; set; }
        public string TenChuHo { get; set; }
    }
}
