﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2021_QuanLyThietBi.Models
{
    public class ThietBi
    {

        public string MaThietBi { get; set; }
        public string TenThietBi { get; set; }
    }
}
